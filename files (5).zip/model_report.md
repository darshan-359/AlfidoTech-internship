# Customer Churn Prediction — Model Selection Report

## 1. Problem Statement
Binary classification: predict whether a customer will churn (leave) based on 15 behavioural
and contractual features. Positive class (churn) makes up ~30% of the dataset, creating a
moderate class imbalance that was addressed via `class_weight="balanced"` in relevant models.

---

## 2. Dataset
| Property | Value |
|---|---|
| Samples | 2,000 |
| Features | 15 (continuous) |
| Target | Binary (churn / retained) |
| Class distribution | 70% retained · 30% churned |
| Train / Test split | 80% / 20% (stratified) |

**Top predictive features** (by Random Forest importance):
1. `tenure_months` — 0.1397
2. `billing_issues` — 0.1394
3. `num_logins` — 0.1355
4. `num_complaints` — 0.1083
5. `support_calls` — 0.1041

---

## 3. Preprocessing
- **StandardScaler** applied inside each `sklearn.Pipeline` to prevent data leakage.
- No missing values in the synthetic dataset.
- Categorical encoding not required (all features continuous).

---

## 4. Models Evaluated

| Model | Rationale |
|---|---|
| Logistic Regression | Strong interpretable baseline; fast; linear decision boundary |
| Random Forest | Ensemble of decision trees; handles non-linearity; robust to outliers |
| Gradient Boosting | Sequential boosting; typically top performer on tabular data |
| SVM (RBF) | Kernel-based; effective in moderate-dimensional space |

---

## 5. Results

### 5a. 5-Fold Stratified Cross-Validation (on training set)

| Model | CV Accuracy | CV F1 | CV ROC-AUC |
|---|---|---|---|
| Logistic Regression | 0.9694 | 0.9506 | 0.9773 |
| Random Forest | 0.9700 | 0.9502 | 0.9813 |
| Gradient Boosting | 0.9738 | 0.9569 | 0.9780 |
| SVM (RBF) | 0.9794 | 0.9664 | **0.9821** |

### 5b. Hold-Out Test Set (20%)

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| Logistic Regression | 0.9725 | 0.9512 | 0.9590 | 0.9551 | 0.9838 |
| Random Forest | 0.9850 | **0.9915** | 0.9590 | 0.9750 | 0.9861 |
| **Gradient Boosting** | **0.9850** | 0.9754 | **0.9754** | **0.9754** | **0.9893** |
| SVM (RBF) | 0.9850 | 0.9833 | 0.9672 | 0.9752 | 0.9848 |

---

## 6. Model Selection: Gradient Boosting ✅

**Gradient Boosting** was selected as the final model for the following reasons:

1. **Highest ROC-AUC (0.9893)** on the held-out test set — the best discriminatory ability
   between churners and non-churners across all decision thresholds.
2. **Most balanced precision/recall** (both 0.9754), meaning it minimises both false positives
   (wasted retention spend) and false negatives (missed churners) equally.
3. **Strong F1 score (0.9754)** — best among all models when weighting both error types equally.
4. **Consistent CV performance** — no signs of overfitting; cross-validation and test metrics
   are closely aligned.

### Trade-offs vs alternatives
| | Gradient Boosting | Random Forest |
|---|---|---|
| Precision | 0.9754 | **0.9915** |
| Recall | **0.9754** | 0.9590 |
| ROC-AUC | **0.9893** | 0.9861 |
| Training speed | Slower | Faster |
| Interpretability | Lower | Moderate (feature importances) |

Random Forest achieves higher precision but lower recall — it misses more churners. For churn
prevention, **recall is typically more business-critical** (catching every potential churner
before they leave), making Gradient Boosting the better overall choice.

---

## 7. Recommendations
- **Threshold tuning:** At the default 0.5 threshold, recall is 0.9754. Lowering to ~0.35
  would further increase recall at a small precision cost — useful if retention campaigns are
  inexpensive.
- **Feature engineering:** `tenure_months` × `num_complaints` interaction could yield further
  gains.
- **Hyperparameter optimisation:** Grid/random search over `n_estimators`, `learning_rate`,
  and `max_depth` is expected to push ROC-AUC above 0.99.
- **Monitoring:** Re-train monthly as customer behaviour shifts over time.

---

*Report generated automatically from model training pipeline.*
