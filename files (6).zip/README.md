# 🤖 ML Inference API

A production-ready REST API that wraps a trained scikit-learn model (Iris classifier) using **FastAPI** and ships as a **Docker** container.

```
POST /predict        → single prediction
POST /predict/batch  → batch predictions
GET  /health         → liveness check
GET  /docs           → interactive Swagger UI
```

---

## 📁 Project Structure

```
ml-api/
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI app, routes, schemas
│   └── model.py         # Training, loading, inference helpers
├── model/
│   └── iris_rf.pkl      # Auto-generated on first run
├── tests/
│   └── test_api.py      # pytest test suite
├── Dockerfile           # Multi-stage production image
├── docker-compose.yml   # Local dev stack
├── requirements.txt
└── sample_requests.sh   # Ready-to-run curl examples
```

---

## 🚀 Quickstart

### Option A — Docker Compose (recommended)

```bash
# 1. Clone & enter the repo
git clone https://github.com/your-username/ml-inference-api.git
cd ml-inference-api

# 2. Build and start
docker compose up --build

# 3. Test
curl http://localhost:8000/health
```

### Option B — Docker (manual)

```bash
docker build -t ml-api .

docker run -p 8000:8000 ml-api
```

### Option C — Local Python

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

uvicorn app.main:app --reload --port 8000
```

---

## 📡 API Reference

### `GET /health`

```bash
curl http://localhost:8000/health
```

**Response**
```json
{
  "status": "ok",
  "model_loaded": true,
  "version": "1.0.0"
}
```

---

### `POST /predict`

Predict the Iris species from four measurements (cm):
`[sepal_length, sepal_width, petal_length, petal_width]`

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"features": [5.1, 3.5, 1.4, 0.2]}'
```

**Response**
```json
{
  "prediction": "setosa",
  "confidence": 1.0,
  "probabilities": {
    "setosa": 1.0,
    "versicolor": 0.0,
    "virginica": 0.0
  },
  "latency_ms": 1.243
}
```

---

### `POST /predict/batch`

Run up to 100 predictions in a single request.

```bash
curl -X POST http://localhost:8000/predict/batch \
  -H "Content-Type: application/json" \
  -d '{
    "instances": [
      [5.1, 3.5, 1.4, 0.2],
      [6.3, 3.3, 4.7, 1.6],
      [6.7, 3.0, 5.2, 2.3]
    ]
  }'
```

**Response**
```json
{
  "predictions": ["setosa", "versicolor", "virginica"],
  "confidences": [1.0, 0.97, 0.98],
  "latency_ms": 2.871
}
```

---

## 🧪 Running Tests

```bash
pip install pytest httpx
pytest tests/ -v
```

Expected output:
```
tests/test_api.py::test_root                  PASSED
tests/test_api.py::test_health                PASSED
tests/test_api.py::test_predict_setosa        PASSED
tests/test_api.py::test_predict_virginica     PASSED
tests/test_api.py::test_predict_wrong_...     PASSED
tests/test_api.py::test_batch_predict         PASSED
tests/test_api.py::test_batch_size_limit      PASSED
```

---

## 🐳 Docker Details

The image uses a **multi-stage build** to keep the final image small:

| Stage    | Base               | Purpose                          |
|----------|--------------------|----------------------------------|
| builder  | python:3.11-slim   | Install dependencies             |
| runtime  | python:3.11-slim   | Copy packages + run the app      |

Security hardening:
- Runs as a **non-root user** (`appuser`)
- Built-in **HEALTHCHECK** via `/health` endpoint
- **2 Uvicorn workers** for concurrent requests

```bash
# Check image size
docker images ml-api

# Inspect running container health
docker inspect --format='{{.State.Health.Status}}' ml-inference-api
```

---

## ⚙️ Configuration

| Environment Variable | Default               | Description           |
|----------------------|-----------------------|-----------------------|
| `MODEL_PATH`         | `model/iris_rf.pkl`   | Path to pickled model |

Override at runtime:
```bash
docker run -e MODEL_PATH=/data/my_model.pkl -p 8000:8000 ml-api
```

---

## 🔄 Swapping in Your Own Model

1. Replace `app/model.py` → update `train_and_save()` and `predict()` to load your model
2. Update the Pydantic schemas in `app/main.py` to match your input features
3. Rebuild the Docker image

---

## 📚 Interactive Docs

Once the container is running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
