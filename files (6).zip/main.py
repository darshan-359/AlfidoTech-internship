"""
ML Model Inference API
A FastAPI service wrapping a trained scikit-learn classifier.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
import time
import logging

from app.model import load_model, predict

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="ML Inference API",
    description="REST API for serving a trained Iris classifier model",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model once at startup
model = None

@app.on_event("startup")
async def startup_event():
    global model
    logger.info("Loading model...")
    model = load_model()
    logger.info("Model loaded successfully.")


# ── Schemas ──────────────────────────────────────────────────────────────────

class PredictRequest(BaseModel):
    features: List[float] = Field(
        ...,
        min_items=4,
        max_items=4,
        example=[5.1, 3.5, 1.4, 0.2],
        description="[sepal_length, sepal_width, petal_length, petal_width] in cm",
    )

class BatchPredictRequest(BaseModel):
    instances: List[List[float]] = Field(
        ...,
        example=[[5.1, 3.5, 1.4, 0.2], [6.7, 3.0, 5.2, 2.3]],
        description="List of feature vectors",
    )

class PredictionResponse(BaseModel):
    prediction: str
    confidence: float
    probabilities: dict
    latency_ms: float

class BatchPredictionResponse(BaseModel):
    predictions: List[str]
    confidences: List[float]
    latency_ms: float

class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    version: str


# ── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/", tags=["Info"])
def root():
    return {"message": "ML Inference API is running. Visit /docs for the interactive API explorer."}


@app.get("/health", response_model=HealthResponse, tags=["Info"])
def health_check():
    return HealthResponse(
        status="ok",
        model_loaded=model is not None,
        version="1.0.0",
    )


@app.post("/predict", response_model=PredictionResponse, tags=["Inference"])
def predict_single(request: PredictRequest):
    """
    Predict the Iris species for a single flower sample.

    Feature order: sepal_length, sepal_width, petal_length, petal_width (all in cm)
    """
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    t0 = time.perf_counter()
    label, confidence, probs = predict(model, [request.features])
    latency = (time.perf_counter() - t0) * 1000

    return PredictionResponse(
        prediction=label[0],
        confidence=round(confidence[0], 4),
        probabilities={k: round(v, 4) for k, v in probs[0].items()},
        latency_ms=round(latency, 3),
    )


@app.post("/predict/batch", response_model=BatchPredictionResponse, tags=["Inference"])
def predict_batch(request: BatchPredictRequest):
    """
    Predict Iris species for multiple samples in one call.
    """
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    if len(request.instances) > 100:
        raise HTTPException(status_code=400, detail="Batch size must be ≤ 100")

    t0 = time.perf_counter()
    labels, confidences, _ = predict(model, request.instances)
    latency = (time.perf_counter() - t0) * 1000

    return BatchPredictionResponse(
        predictions=labels,
        confidences=[round(c, 4) for c in confidences],
        latency_ms=round(latency, 3),
    )
