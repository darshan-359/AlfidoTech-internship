"""
Model training, persistence, and inference helpers.
Trains a RandomForest on the Iris dataset if no saved model is found.
"""

import os
import pickle
import logging
from typing import List, Tuple, Dict

import numpy as np
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

logger = logging.getLogger(__name__)

MODEL_PATH = os.getenv("MODEL_PATH", "model/iris_rf.pkl")
CLASS_NAMES = ["setosa", "versicolor", "virginica"]


def train_and_save() -> RandomForestClassifier:
    """Train a RandomForest on Iris and persist it."""
    logger.info("Training new model...")
    iris = load_iris()
    X_train, X_test, y_train, y_test = train_test_split(
        iris.data, iris.target, test_size=0.2, random_state=42
    )
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_train, y_train)

    acc = accuracy_score(y_test, clf.predict(X_test))
    logger.info(f"Model trained — test accuracy: {acc:.4f}")

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(clf, f)
    logger.info(f"Model saved to {MODEL_PATH}")
    return clf


def load_model() -> RandomForestClassifier:
    """Load persisted model, or train a fresh one."""
    if os.path.exists(MODEL_PATH):
        logger.info(f"Loading model from {MODEL_PATH}")
        with open(MODEL_PATH, "rb") as f:
            return pickle.load(f)
    return train_and_save()


def predict(
    model: RandomForestClassifier,
    features: List[List[float]],
) -> Tuple[List[str], List[float], List[Dict[str, float]]]:
    """
    Run inference on a batch of feature vectors.

    Returns:
        labels       – class name for each sample
        confidences  – max class probability for each sample
        probs_list   – full probability dict per sample
    """
    X = np.array(features)
    proba = model.predict_proba(X)          # shape (n, 3)
    indices = np.argmax(proba, axis=1)

    labels = [CLASS_NAMES[i] for i in indices]
    confidences = [float(proba[i, idx]) for i, idx in enumerate(indices)]
    probs_list = [
        {CLASS_NAMES[j]: float(proba[i, j]) for j in range(len(CLASS_NAMES))}
        for i in range(len(features))
    ]
    return labels, confidences, probs_list
