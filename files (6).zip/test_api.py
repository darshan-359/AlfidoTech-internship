"""
Unit + integration tests for the ML Inference API.
Run with: pytest tests/ -v
"""

import pytest
from fastapi.testclient import TestClient

# Patch model path before importing app
import os
os.environ["MODEL_PATH"] = "model/iris_rf.pkl"

from app.main import app

client = TestClient(app)


def test_root():
    r = client.get("/")
    assert r.status_code == 200
    assert "running" in r.json()["message"]


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert data["model_loaded"] is True


def test_predict_setosa():
    r = client.post("/predict", json={"features": [5.1, 3.5, 1.4, 0.2]})
    assert r.status_code == 200
    data = r.json()
    assert data["prediction"] == "setosa"
    assert data["confidence"] > 0.9
    assert set(data["probabilities"].keys()) == {"setosa", "versicolor", "virginica"}
    assert data["latency_ms"] > 0


def test_predict_virginica():
    r = client.post("/predict", json={"features": [6.7, 3.0, 5.2, 2.3]})
    assert r.status_code == 200
    assert r.json()["prediction"] == "virginica"


def test_predict_wrong_feature_count():
    r = client.post("/predict", json={"features": [5.1, 3.5]})
    assert r.status_code == 422   # Unprocessable Entity


def test_batch_predict():
    payload = {
        "instances": [
            [5.1, 3.5, 1.4, 0.2],
            [6.3, 3.3, 4.7, 1.6],
            [6.7, 3.0, 5.2, 2.3],
        ]
    }
    r = client.post("/predict/batch", json=payload)
    assert r.status_code == 200
    data = r.json()
    assert len(data["predictions"]) == 3
    assert data["predictions"][0] == "setosa"
    assert data["predictions"][2] == "virginica"


def test_batch_size_limit():
    payload = {"instances": [[5.1, 3.5, 1.4, 0.2]] * 101}
    r = client.post("/predict/batch", json=payload)
    assert r.status_code == 400
